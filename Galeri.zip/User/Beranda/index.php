
<!-- Main content -->
<section class="content">

  <div class="container">
    <div class="row">
		<div align="center">
			<h1>SELAMAT DATANG DI BERANDA</h1>
			<br>
			<h3>E - GALERI</h3>
			<br>
			<img src="../Assets/image/logo/smk1.png" height="200px" width="200px" class="user-image" alt="User Image"> 
		</div>
	</div>
  </div>

</section><!-- /.content -->
